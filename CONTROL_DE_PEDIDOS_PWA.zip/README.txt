CONTROL DE PEDIDOS - PWA
=========================

Esta carpeta contiene una versión instalable (PWA) de la portada de Control de Pedidos.

Incluye:
- Dashboard visual.
- Indicadores: total, urgentes, normales, pagos pendientes/en proceso/completados.
- Botón PEDIDOS que abre el sistema Apps Script actual.
- Manifest y Service Worker para instalación como app.

IMPORTANTE:
La publicación debe hacerse en un sitio HTTPS (por ejemplo GitHub Pages, Cloudflare Pages o similar).
La URL de Apps Script queda como backend/pantalla de pedidos.

Antes de ponerla en producción, conviene conectar el Dashboard a datos reales de la hoja mediante un endpoint JSON de Apps Script para que los contadores sean dinámicos.
